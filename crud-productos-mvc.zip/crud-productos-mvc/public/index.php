<?php
// Front Controller

// Incluir autoloader si es necesario
require_once '../config/database.php';

// Obtener controlador y acción
$controller = $_GET['controller'] ?? 'producto';
$action = $_GET['action'] ?? 'index';

// Convertir a formato de nombre de clase
$controller = ucfirst($controller) . 'Controller';

// Verificar si el archivo del controlador existe
$controller_file = '../controllers/' . $controller . '.php';

if(file_exists($controller_file)) {
    require_once $controller_file;
    
    // Crear instancia del controlador
    $controller_instance = new $controller();
    
    // Verificar si la acción existe
    if(method_exists($controller_instance, $action)) {
        // Ejecutar la acción
        $controller_instance->$action();
    } else {
        // Acción no encontrada
        http_response_code(404);
        echo 'Acción no encontrada';
    }
} else {
    // Controlador no encontrado
    http_response_code(404);
    echo 'Controlador no encontrado';
}
?>