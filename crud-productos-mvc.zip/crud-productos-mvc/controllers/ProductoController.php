<?php
require_once 'models/Producto.php';

class ProductoController {
    private $model;

    public function __construct() {
        $this->model = new Producto();
    }

    // Listar todos los productos
    public function index() {
        $productos = $this->model->getAll();
        require_once 'views/productos/index.php';
    }

    // Mostrar formulario para crear producto
    public function create() {
        require_once 'views/productos/create.php';
    }

    // Guardar nuevo producto
    public function store() {
        session_start();
        $_SESSION['errors'] = [];

        // Validaciones
        if(empty($_POST['nombre']) || strlen($_POST['nombre']) < 3) {
            $_SESSION['errors']['nombre'] = 'El nombre es obligatorio y debe tener al menos 3 caracteres';
        }
        
        if(empty($_POST['precio']) || $_POST['precio'] <= 0) {
            $_SESSION['errors']['precio'] = 'El precio es obligatorio y debe ser mayor que 0';
        }
        
        if(!is_numeric($_POST['stock']) || $_POST['stock'] < 0) {
            $_SESSION['errors']['stock'] = 'El stock debe ser un número entero no negativo';
        }

        // Si hay errores, volver al formulario
        if(!empty($_SESSION['errors'])) {
            $_SESSION['old'] = $_POST;
            header('Location: index.php?controller=producto&action=create');
            exit();
        }

        // Crear producto
        $this->model->nombre = $_POST['nombre'];
        $this->model->descripcion = $_POST['descripcion'];
        $this->model->precio = $_POST['precio'];
        $this->model->stock = $_POST['stock'];

        if($this->model->create()) {
            $_SESSION['success'] = 'Producto creado exitosamente';
        } else {
            $_SESSION['error'] = 'Error al crear el producto';
        }

        header('Location: index.php?controller=producto&action=index');
    }

    // Mostrar formulario para editar producto
    public function edit() {
        $id = $_GET['id'] ?? 0;
        
        if($this->model->getById($id)) {
            require_once 'views/productos/edit.php';
        } else {
            header('Location: index.php?controller=producto&action=index');
        }
    }

    // Actualizar producto
    public function update() {
        session_start();
        $_SESSION['errors'] = [];

        // Validaciones
        if(empty($_POST['nombre']) || strlen($_POST['nombre']) < 3) {
            $_SESSION['errors']['nombre'] = 'El nombre es obligatorio y debe tener al menos 3 caracteres';
        }
        
        if(empty($_POST['precio']) || $_POST['precio'] <= 0) {
            $_SESSION['errors']['precio'] = 'El precio es obligatorio y debe ser mayor que 0';
        }
        
        if(!is_numeric($_POST['stock']) || $_POST['stock'] < 0) {
            $_SESSION['errors']['stock'] = 'El stock debe ser un número entero no negativo';
        }

        // Si hay errores, volver al formulario
        if(!empty($_SESSION['errors'])) {
            $_SESSION['old'] = $_POST;
            header('Location: index.php?controller=producto&action=edit&id=' . $_POST['id']);
            exit();
        }

        // Actualizar producto
        $this->model->id = $_POST['id'];
        $this->model->nombre = $_POST['nombre'];
        $this->model->descripcion = $_POST['descripcion'];
        $this->model->precio = $_POST['precio'];
        $this->model->stock = $_POST['stock'];

        if($this->model->update()) {
            $_SESSION['success'] = 'Producto actualizado exitosamente';
        } else {
            $_SESSION['error'] = 'Error al actualizar el producto';
        }

        header('Location: index.php?controller=producto&action=index');
    }

    // Mostrar confirmación para eliminar
    public function delete() {
        $id = $_GET['id'] ?? 0;
        
        if($this->model->getById($id)) {
            require_once 'views/productos/delete.php';
        } else {
            header('Location: index.php?controller=producto&action=index');
        }
    }

    // Eliminar producto
    public function destroy() {
        session_start();
        
        $this->model->id = $_POST['id'];
        
        if($this->model->delete()) {
            $_SESSION['success'] = 'Producto eliminado exitosamente';
        } else {
            $_SESSION['error'] = 'Error al eliminar el producto';
        }

        header('Location: index.php?controller=producto&action=index');
    }
}
?>