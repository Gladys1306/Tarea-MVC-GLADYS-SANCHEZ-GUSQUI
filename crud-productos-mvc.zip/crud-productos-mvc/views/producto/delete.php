<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Producto</title>
    <link rel="stylesheet" href="../public/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header bg-danger text-white">
                        <h3 class="text-center">Confirmar Eliminación</h3>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-warning">
                            <h5><i class="fas fa-exclamation-triangle"></i> ¡Advertencia!</h5>
                            <p>¿Estás seguro que deseas eliminar el siguiente producto?</p>
                            <hr>
                            <p><strong>Nombre:</strong> <?= htmlspecialchars($producto->nombre); ?></p>
                            <p><strong>Precio:</strong> $<?= number_format($producto->precio, 2); ?></p>
                            <p><strong>Stock:</strong> <?= $producto->stock; ?></p>
                            <p class="text-danger"><small>Esta acción no se puede deshacer.</small></p>
                        </div>

                        <form action="index.php?controller=producto&action=destroy" method="POST">
                            <input type="hidden" name="id" value="<?= $producto->id ?>">
                            
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-danger">
                                    <i class="fas fa-trash"></i> Sí, Eliminar Producto
                                </button>
                                <a href="index.php?controller=producto&action=index" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>