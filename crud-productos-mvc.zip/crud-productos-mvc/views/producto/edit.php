<?php
session_start();
$errors = $_SESSION['errors'] ?? [];
$old = $_SESSION['old'] ?? [];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Producto</title>
    <link rel="stylesheet" href="../public/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-center">Editar Producto</h3>
                    </div>
                    <div class="card-body">
                        <form action="index.php?controller=producto&action=update" method="POST">
                            <input type="hidden" name="id" value="<?= $producto->id ?>">
                            
                            <div class="mb-3">
                                <label for="nombre" class="form-label">Nombre *</label>
                                <input type="text" class="form-control <?= isset($errors['nombre']) ? 'is-invalid' : '' ?>" 
                                       id="nombre" name="nombre" 
                                       value="<?= $old['nombre'] ?? $producto->nombre ?>" required>
                                <?php if(isset($errors['nombre'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['nombre']; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"><?= $old['descripcion'] ?? $producto->descripcion ?></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="precio" class="form-label">Precio *</label>
                                <input type="number" step="0.01" class="form-control <?= isset($errors['precio']) ? 'is-invalid' : '' ?>" 
                                       id="precio" name="precio" 
                                       value="<?= $old['precio'] ?? $producto->precio ?>" required>
                                <?php if(isset($errors['precio'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['precio']; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <label for="stock" class="form-label">Stock *</label>
                                <input type="number" class="form-control <?= isset($errors['stock']) ? 'is-invalid' : '' ?>" 
                                       id="stock" name="stock" 
                                       value="<?= $old['stock'] ?? $producto->stock ?>" required>
                                <?php if(isset($errors['stock'])): ?>
                                    <div class="invalid-feedback">
                                        <?= $errors['stock']; ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Actualizar Producto
                                </button>
                                <a href="index.php?controller=producto&action=index" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Volver al Listado
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>